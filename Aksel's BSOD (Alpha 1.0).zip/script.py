from ursina import *
from ursina.prefabs import first_person_controller

app=Ursina()
window.title="Aksel's BSOD (Alpha 1.0)"
#window.size=window.fullscreen_size
first_size=window.size
window.borderless = False

player=first_person_controller.FirstPersonController()
player.collider="box"

player.speed=3

floor=Entity(model="assets/floor.obj", texture="assets/images/floor.png")
floor.collider="box"

from ursina.shaders import basic_lighting_shader
walls=Entity(model="assets/walls.obj", texture="assets/images/walls.png", shader=basic_lighting_shader)
walls.collider="mesh"

text=Text("Press Esc to pause the game.\nPress E to kill the game.\nPress M to free the mouse.", position=(-0.75, 0.5))

comp=Entity(model="assets/computer.obj", texture="assets/images/computer.png", rotation=(0, -90, 0), shader=basic_lighting_shader, position=(-2, 0, 4), scale=(1.3, 1.3, 1.3))

shifted=False
sprinted=False

def update():
	global shifted, sprinted
	if held_keys["e"]:
		quit()

	if held_keys["shift"]:
		if shifted == False:
			player.y-=0.5
			shifted=True
	else:
		if shifted==True:
			player.y+=0.5
			shifted=False

	if held_keys["c"]:
		if sprinted == False:
			player.speed=6
			sprinted=True
	else:
		if sprinted == True:
			player.speed=3
			sprinted=False

def input(key):
	global first_size
	if key == "escape":
		if mouse.locked == True:
			mouse.locked=False
			application.paused=True
	elif key == "f12":
		if window.size!=window.fullscreen_size:
			window.size=window.fullscreen_size
		elif window.size==window.fullscreen_size:
			window.size=first_size
	elif key == "m":
		if mouse.locked==True:
			mouse.locked=False
		elif mouse.locked==False:
			mouse.locked=True


app.run()